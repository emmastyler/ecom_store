const user = (async (req, res) => {
    res.send('dashboard').status(200);
})

module.exports = {user};