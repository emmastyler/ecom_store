const jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');
const connection = require('../connect');

const {sendConfirmationEmail, sendLoginPin} = require('../email/transporter');


const createUser = (async (req, res, next) => {

    try {
        const { 
            firstname, 
            lastname, 
            email, 
            password,
            phone,
            city,
            state,
            country,
            address,
            district,

            } = req.body;
        const token = jwt.sign({email:email}, process.env.JWT_SECRET);

        const salt = bcrypt.genSaltSync(10);
        const hashedPassword = bcrypt.hashSync(password, salt);
        const confirmationCode =  token;
    
        //!check if user exists

        let userExist = `SELECT * FROM coredb WHERE email = ? OR Phone = ? `;
        connection.query(userExist, [email, phone], function (err, result) {
            if (err) throw err;
            if (result.length > 0) {
               
                const user = result.map((user) =>
                    {
                    return {
                        values: user.Email === email ? 'Email' : user.Phone === phone ? 'Phone Number' : '',
                        key: user.Email? user.Email : user.Phone? user.Phone : user

                            }
                    })

                if(user !== undefined){
                    const values = user.map((uservalue) => uservalue.values);
                    res.status(500).json({
                        message:`${values[0]} already exists`
                    });
                    //console.log(process.env.PORT);
                }
            }
            else {

                    // program to generate random strings for UserId

                    // declare all characters
                    const characters ='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
                    const character ='0123456789';

                    function generateString(length) {
                        let result = ' ';
                        const charactersLength = characters.length;
                        for ( let i = 0; i < length; i++ ) {
                            result += characters.charAt(Math.floor(Math.random() * charactersLength));
                        }

                        return result.trim();
                    }

                    function generateString2(length) {
                        let results = ' ';
                        const characterLength = character.length;
                        for ( let i = 0; i < length; i++ ) {
                            results += character.charAt(Math.floor(Math.random() * characterLength));
                        }

                        return results.trim();
                    }
                    const userId = generateString(16);
                    const blockChainId = generateString2(2);
                   
                    connection.query('SELECT * FROM coredb', (err, result) => {
                        if (err) throw err;
                        
                        const insertID = `G-${result.length + 1}${blockChainId}`;
                        console.log(blockChainId);   

                        let sql = `INSERT INTO coredb (FirstName, LastName, email, Password, Phone, Country, State, City, Address, District, Status,UserID, BlockchainID,Pin, ProfileImage,Label, LoginAuth, token) VALUES ('${firstname}', '${lastname}', '${email}', '${hashedPassword}','${phone}','${country}','${state}', '${city}','${address}','${district}','Pending','${userId}','${insertID}','','','','','${confirmationCode}' )`;
                        connection.query(sql, function (err, result) {
                            if (err) throw err;
                    
                            //!This is for fetching newly created users
                    
                            connection.query(`SELECT * FROM coredb WHERE ID = ${result.insertId}`, (err, result) => {
                            if (err) throw err;
                            
                            console.log(result);    
                            });
                        
                        });

                        });
                        
                    console.log(userId);
                    sendConfirmationEmail(
                    firstname,
                    email,
                    confirmationCode
             );
             console.log(firstname + ' ' + email );
             res.status(201).json({message: 'User created successfully'});
            }
             
        });

        
    } catch (error) {
        console.log(error);
    }


});

const loginUser = (async (req, res, next) => {
   try {
    const { blockChainId, password } = req.body;
    
    let sql = `SELECT * FROM coredb WHERE BlockchainID = ?`;
    connection.query(sql, [blockChainId], function(err, result) {
        if (err) throw err;
        if(result.length > 0){
            const user = result.map((user) =>
            {
            return {
                status:user.Status === 'Pending'? 'Pending' : user.Status === 'Active'? 'Active' : '',
                details: {
                    firstName:user.FirstName,
                    lastName:user.LastName,
                    email:user.Email,
                    password:user.Password,
                    blockChainId:user.BlockchainID,
                    
                },
                key: user.BlockchainId? user.BlockchainId : user.Password? user.Password : user
                    }
            });
    
            const statuses = user.map((userstatus) => userstatus);
            const status = statuses[0];

            //console.log(status.details.firstName);
           // if ((bcrypt.compare(password, status.details.password))) {
                
                 
                if(status.status === 'Pending'){
                    //const values = user.map((uservalue) => uservalue.values);
                    res.status(500).json({
                        message:`Please click link sent to your email to activate your account`
                    });
                    //console.log(process.env.PORT);
                }

                else if(status.status === 'Active'){
                
                    const character ='0123456789';

                    function generateString2(length) {
                        let results = ' ';
                        const characterLength = character.length;
                        for ( let i = 0; i < length; i++ ) {
                            results += character.charAt(Math.floor(Math.random() * characterLength));
                        }

                        return results.trim();
                    }

                    const LoginPin = generateString2(5);

                   
                    const name = status.details.firstName;
                    const email = status.details.email;

                    console.log(email, name);

                    sendLoginPin(
                        name, 
                        email,
                        LoginPin
                         );
                    let loginauth = 'UPDATE coredb SET LoginAuth =? WHERE Email =?';
                    connection.query(loginauth, [LoginPin, email], function(err, result) {
                        if (err) throw err;

                        if(result.affectedRows > 0){
                            console.log('LoginPin updated successfully');
                        }
                    })
                    res.status(200).json({
                    'message': 'Login Pin Sent',
                    'blockChainId': status.details.blockChainId,
                    
                    });
                }

            //}

        }
        else {
            res.status(500).json({'message':'Blockchain ID or Password is incorrect'});
            console.log('No record found');
        }
       
    });
   } catch (error) {
    console.log(error);
   }

});

const validateUser = (async (req, res, next) => {
    try {
        const { loginPin, blockChainId } = req.body;

        const sql = `SELECT * FROM coredb WHERE LoginAuth =? AND BlockchainID =?`;
        connection.query(sql, [loginPin, blockChainId], function(err, result) {
            if (err) throw err;
            if(result.length > 0){

                 // Create token
                const tokenSecret = jwt.sign(
                    { pin: loginPin },
                    process.env.JWT_SECRET,
                    {
                    expiresIn: "3m",
                    }
                );
                res.status(200).json({
                    'token': tokenSecret,
                    'message':'Login Successfull',
                    
                })   
            }
            else {
                res.status(500).json({'message':'Login Pin is incorrect'});
                console.log('No record found');
            }
        })
        
    } catch (error) {
        
    }
})

module.exports = {createUser, loginUser, validateUser}; 