const express = require('express');
const Router = express.Router();
const authController = require('../Controllers/authController');

Router.post('/api/register', authController.createUser);
Router.post('/login', authController.loginUser);
Router.post('/login/verify', authController.validateUser);



module.exports = Router; 