
const transport = require('./config')
const sendConfirmationEmail = (name, email, confirmationCode) => {
    console.log("Check");

    transport.sendMail({
      from: 'GimaBlockchain',
      to: email,
      subject: "Please confirm your account",
      html: `<h1>Email Confirmation</h1>
      <h2>Hello ${name}</h2>
      <p>Thank you for subscribing. Please confirm your email by clicking on the following link</p>
      <a href=http://localhost:3000/confirm/?confirmationCode=${confirmationCode}> Click here</a>
      </div>`,
    }, function(error, info) {
        if (error) {
            console.log(error);
        } else {
            console.log("Email sent: " + info.response);
            transport.close();
        }
    })
  };


  const sendLoginPin = (name, email, LoginPin) => {
    console.log("Check");

    transport.sendMail({
      from: 'GimaBlockchain',
      to: email,
      subject: "Please confirm your account",
      html: `<h1>Email Confirmation</h1>
      <h2>Hello ${name}</h2>
      <p>Thank you for subscribing. Here is your Login Pin</p>
      <p>${LoginPin}</p>      
      </div>`,
    }, function(error, info) {
        if (error) {
            console.log(error);
        } else {
            console.log("Email sent: " + info.response);
            transport.close();
        }
    })
  };

  module.exports = {sendConfirmationEmail, sendLoginPin};